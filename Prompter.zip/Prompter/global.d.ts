/// <reference path="node_modules/@zeppos/device-types/dist/index.d.ts" />
