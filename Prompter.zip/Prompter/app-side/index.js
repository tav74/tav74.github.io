import { BaseSideService } from '@zeppos/zml/base-side'
import { settingsLib } from '@zeppos/zml/base-side'



async function fetchData(url) {
  try {
    const response = await fetch(url)
    const text =  response.body
    console.log('✅ Fetch текст:', text)
    return text
  } catch (error) {
    console.log('❌ Fetch error:', error)
    return error.message
  }
}


AppSideService(
  BaseSideService({
    
    onInit() {
      this.log('SideService init')
  
    },

    
     onSettingsChange({ key, newValue, oldValue }) 
    {
      
      this.log('изменение из onSettingsChange',key, newValue, oldValue)

      //const result = this.call({
      //method: 'onSettingsChange',
      //params: 'Тест настроек' // Передаем данные дальше
    //});   
    
    this.request({
        method: 'onSettingsChange',
        params: 'Изменение настроек.'
      })

    },


     async onRequest(req, res) { 

if (req.method === 'GET_IMAGE') {


  //const phoneIp = settingsLib.getItem('phone_ip') || '0.0.0.0'
  const phoneIp = req.params.phoneIp
  const url = `http://${phoneIp}:8080/special/1.png`    

  const downloadTask = network.downloader.downloadFile({
        //url: 'http://alexeylab.ru/images/my.png',
        url,
        headers: {},
        timeout: 60000,
        //filePath: 'data://download/1.png'
        filePath: req.params.filename
      })

        downloadTask.onFail = (event) => {
        console.log(event.code)
        console.log(event.message)

            const result = this.call({
            method: 'onFail',
            params: event.message+' код: '+event.code
        });
      }

      downloadTask.onSuccess = (event) => {

            const result = this.call({
            method: 'onRequest',
            params: event.filePath
          });
}

   }
   else if (req.method === 'SAVE_IMAGE') {
    const outbox = transferFile.getOutbox()
    console.log('имя файла для записи на часы: ', req.params);
      //const fileObject = outbox.enqueueFile('data://download//download//1.png', {
      const fileObject = outbox.enqueueFile(req.params, {
      type: 'image',
      name: req.params
    });


    // Отслеживаем прогресс передачи
    fileObject.on('progress', (event) => {
      console.log('progress total size', event.data.fileSize);
      console.log('progress loaded size', event.data.loadedSize);
    });

    // Отслеживаем изменение состояния
    fileObject.on('change', (event) => {
      if (event.data.readyState === 'transferred') {

        console.log('file transferred successfully');
            const result = this.call({
            method: 'onSaved',
            params: 'test.png'});

      } else if (event.data.readyState === 'error') 
      {
        console.log('transfer error');
        const result = this.call({
            method: 'onRequest',
            params: 'Ошибка передачи на часы!'});
      }
    }); 

   }
    else if (req.method === 'GET_TEXT') {

      //const phoneIp = settingsLib.getItem('phone_ip') || '0.0.0.0'
      const phoneIp = req.params.phoneIp
      console.log('пришли в получение текста', phoneIp);
      const url = `http://${phoneIp}:8080/api/getText`   
        
      const text = await fetchData(url);
  
       const result = this.call({
            method: 'onTextReceived',
            params: text});
          
    }

},
    
    onRun() {},
    onDestroy() {}
  })
)
