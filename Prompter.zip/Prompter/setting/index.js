AppSettingsPage({
  state: {
    phoneIP: '', // Состояние для реактивности
  },

  build(props) {
    // 1. Загружаем данные из storage в state
    this.state.phoneIP = props.settingsStorage.getItem('phone_ip') || ''

    return View({
      style: { padding: '12px 20px' },
    }, [
      // Тестовая кнопка
      Button({
        label: 'Тест',
        style: {
          fontSize: '14px',
          borderRadius: '24px',
          padding: '6px 18px',
          background: '#409EFF',
          color: '#fff',
        },
        onClick: () => {
          props.settingsStorage.setItem(
            'uploadedImage',
            JSON.stringify({
              text: 'Привет с телефона',
              ts: Date.now(),
            })
          )          
        },
      }),

      View({ style: { height: '24px' } }),

      // IP поле с состоянием
      TextInput({
        label: 'IP сервиса, без порта:',
        value: this.state.phoneIP,
        onChange: (val) => {
          this.state.phoneIP = val // Обновляем state
          props.settingsStorage.setItem('phone_ip', val) // Сохраняем в storage
        },
      }),
    ])
  },
})
