AppSettingsPage({
  build(props) {
    return View({
      style: { padding: '12px 20px' }
    }, [
      Button({
        label: 'Тест',
        style: {
          fontSize: '14px',
          borderRadius: '24px',
          padding: '6px 18px',
          background: '#409EFF',
          color: '#fff'
        },
        onClick: () => {
          props.settingsStorage.setItem(
            'uploadedImage',
            JSON.stringify({
              text: 'Привет с телефона',
              ts: Date.now()
            })
          )
        }
      }),
      
      View({ style: { height: '24px' } }),  // ✅ 24px пробел**
      
      TextInput({
        label: 'IP телефона',
        value: props.settingsStorage.getItem('phone_ip') || "",
        onChange: (val) => {
          props.settingsStorage.setItem('phone_ip', val)
        }
      })
    ])
  }
})
