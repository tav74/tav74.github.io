import { statSync, writeFileSync as writeFile, readFileSync as readFile } from '@zos/fs'

import { TODO_FILE_NAME } from './constants'

export function readFileSync() {
  const fStat = statSync({
    path: this.fileName
  })
  if (fStat) {
    const resData = readFile({
      path: TODO_FILE_NAME,
      options: {
        encoding: 'utf8'
      }
    })
    return !resData ? [] : JSON.parse(resData)
  } else {
    return []
  }
}

export function writeFileSync(data, merge = true) {
  let params = data
  if (merge) {
    params = [...readFile(), ...data]
  }
  writeFile({
    path: TODO_FILE_NAME,
    data: JSON.stringify(params),
    options: {
      encoding: 'utf8'
    }
  })
}

export function formatTimestampForFilename(currentTimestamp) {
  const d = new Date(currentTimestamp)

  const pad = (n) => (n < 10 ? `0${n}` : `${n}`)

  const day = pad(d.getDate())
  const month = pad(d.getMonth() + 1)    
  const year = d.getFullYear()

  const hours = pad(d.getHours())
  const minutes = pad(d.getMinutes())
  const seconds = pad(d.getSeconds())

  return `${day}.${month}.${year} ${hours}_${minutes}_${seconds}`
}

