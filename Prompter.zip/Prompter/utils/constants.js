export const DEFAULT_TODO_LIST = ['Learn'] //  'Drink', 'Food'

export const TODO_FILE_NAME = 'fs_todo_list.txt'
