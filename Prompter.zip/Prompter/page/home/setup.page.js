import { back } from '@zos/router'
import { createWidget, widget, align, prop } from '@zos/ui'
import { localStorage } from '@zos/storage'
import { showKeyboardInput } from './utils.js'
import * as hmUI from '@zos/ui'


Page({
  state: {
    currentIP: '192.168.1.100', // Храним для обновления UI
    ipTextWidget: null, // ✅ ССЫЛКА на виджет
  },

  onInit(params) {
    // Загружаем IP из localStorage
    this.state.currentIP = localStorage.getItem('server_ip', '192.168.1.100')    
  },

  build() {
    // ✅ ТЕКСТ IP НАД кнопкой (центрированный)
    this.state.ipTextWidget = createWidget(widget.TEXT, {
      x: 40,
      y: 80,
      w: px(400),
      h: px(50),
      text: `Текущий IP: ${this.state.currentIP}`,
      color: 0xffffff,
      text_size: px(24),
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V,
      bg_color: 0x33333366, // Полупрозрачный фон
      radius: px(12),
    })

    // ✅ Кнопка ПОД текстом
    createWidget(widget.BUTTON, {
      x: 95,
      y: 150,
      w: px(300),
      h: px(100),
      text: 'Изменить IP сервера',
      normal_color: 0x00a86b,
      press_color: 0x007a4d,
      radius: px(8),
      click_func: () => {
        showKeyboardInput('NUM', this.state.currentIP).then((value) => {
          if (value) {
            console.log('Новый IP:', value)
            
            // ✅ Сохраняем В localStorage
            localStorage.setItem('server_ip', value)
            
            // ✅ Обновляем UI мгновенно (без перезагрузки страницы)
            
            this.state.currentIP = value
            this.state.ipTextWidget.setProperty(prop.TEXT, `Текущий IP: ${value}`)

            hmApp.setCurrentTitle(`Сервер: ${value}`)
            
          } else {
            console.log('Ввод отменён')
            back()
          }
        })
      },
    })

    // Кнопка назад (опционально)
    createWidget(widget.BUTTON, {
      x: 200,
      y: 400,
      w: px(80),
      h: px(40),
      text: '← Назад',
      normal_color: 0x666666,
      press_color: 0x444444,
      radius: px(6),
      click_func: back,
    })
  },
})
