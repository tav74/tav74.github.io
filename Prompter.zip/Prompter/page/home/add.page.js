import { back } from '@zos/router'
import { createWidget, widget, align, prop } from '@zos/ui'
import { myKeyboard } from './utils.js'

Page({
  onInit(params) {

     if (typeof params === 'string') {
      try {
        this.params = JSON.parse(params)
      } catch (e) {
        this.params = { raw: params }
      }
    } else {
      this.params = params || {}
    }
    
  },

  build() {
    
      const { from = '', value = '' } = this.params  
      myKeyboard(from,value)     
      createWidget(widget.BUTTON, {
      x: 95,
      y: 150,
      w: px(300),
      h: px(100),
      text: 'Click to return!',
      normal_color: 0x00a86b,
      press_color: 0x007a4d,
      radius: px(8),
      click_func: () => back(),
    }) 


  },

  
});
