import { push } from '@zos/router'
import * as hmUI from "@zos/ui";
import { getText } from "@zos/i18n";
import { getDeviceInfo } from "@zos/device";
import { px } from "@zos/utils";

import { createWidget, widget, deleteWidget, align, text_style, prop } from '@zos/ui'
import { createKeyboard, inputType, deleteKeyboard } from '@zos/ui'
import { writeFileSync, readFileSync, statSync } from "@zos/fs";
import { readdirSync } from '@zos/fs'
import { Time } from '@zos/sensor'

import { mkdirSync } from '@zos/fs'

const TXT_DIR = 'TXT'
let fileListWidget = null; // Глобальная переменная для хранения виджета

export function myKeyboard(initialText = '', customFilename = null) 
{
  createKeyboard({
      inputType: inputType.TEXT,     // системная раскладка (в т.ч. русская)
      text: initialText,              // стартовое значение

      onComplete: (_, result) => 
        {
        // result.data — введённая строка
        const value = result.data || ''
        
        let filenameBase;
        
        // Если задано пользовательское имя файла - используем его
        if (customFilename !== null && customFilename !== undefined && customFilename !== '') {
          filenameBase = customFilename;
          console.log('Используем заданное имя файла: ' + filenameBase);
        } else {
          // Иначе генерируем имя на основе времени
          const time = new Time();
          const currentTimestamp = time.getTime();
          filenameBase = formatTimestampForFilename(currentTimestamp);
          console.log('Генерируем имя файла на основе времени: ' + filenameBase);
        }
        
        console.log('Записываем данные: ' + value);
        const success = saveData(value, filenameBase);

        hmUI.showToast({
          text: success
        });

        deleteKeyboard();
      },

      onCancel: () => {
        console.log('Ввод отменён');
        deleteKeyboard();
      }
    });
}


export function openKeyboard(initialText = '', onDone)
{
  createKeyboard
  ({
    inputType: inputType.TEXT,
    text: initialText,

    onComplete: (_, result) => {
      const value = result.data || ''
      if (typeof onDone === 'function') {
        onDone(value)
      }
      deleteKeyboard()

    },

    onCancel: () => {
      deleteKeyboard()
      //resolve(null) 
    },
  })
}

export function showKeyboardInput(inputTypeValue = 'CHAR', initialText = '') {
  return new Promise((resolve) => {
    // Определяем тип клавиатуры
    let keyboardType;
    switch(inputTypeValue) {
      case 'NUM':
        keyboardType = inputType.NUM;
        break;
      case 'EMOJI':
        keyboardType = inputType.EMOJI;
        break;
      case 'VOICE':
        keyboardType = inputType.VOICE;
        break;
      case 'CHAR':
      default:
        keyboardType = inputType.CHAR;
        break;
    }

    // Создаём клавиатуру
    createKeyboard({
      inputType: keyboardType,
      
      // Колбэк при подтверждении ввода
      onComplete: (keyboardWidget, result) => {
        console.log('Ввод завершён:', result.data);
        deleteKeyboard();
        resolve(result.data || ''); // Возвращаем введённое значение
      },
      
      // Колбэк при отмене ввода
      onCancel: (keyboardWidget, result) => {
        console.log('Ввод отменён');
        deleteKeyboard();
        resolve(''); // Возвращаем пустую строку
      },
      
      // Начальный текст (опционально)
      text: initialText
    });
  });
}


function formatTimestampForFilename(currentTimestamp) {
  const d = new Date(currentTimestamp)

  const pad = (n) => (n < 10 ? `0${n}` : `${n}`)

  const day = pad(d.getDate())
  const month = pad(d.getMonth() + 1)    // месяцы 0–11
  const year = d.getFullYear()

  const hours = pad(d.getHours())
  const minutes = pad(d.getMinutes())
  const seconds = pad(d.getSeconds())

  // В имени файла лучше заменить ':' на '_' или '-'
  // чтобы не ломать совместимость с FS
  return `${day}.${month}.${year} ${hours}_${minutes}_${seconds}`
}

function ensureTxtDir() {
  try {
    mkdirSync({ path: TXT_DIR })
  } catch (e) {
    // Обычно сюда попадаем, если папка уже существует — можно игнорировать
  }
}

// Функция для сохранения данных в файл
export function saveData(text, filename) 
{

  try {
    ensureTxtDir()
    const fullPath = `${TXT_DIR}/${filename}`;

    const result = writeFileSync({
      path: fullPath,
      data: text,
      options: {
        encoding: 'utf8' // В документации обычно строка
      }
    });

    console.log("Данные успешно сохранены");
    return 'OK';
  } catch (error) {
    console.log("Ошибка при сохранении:", error);
    return 'Error';
  }

}

export function searchFilesByName(query, directory = './') 
{
  try {
    // 1. Получаем список всех имен файлов в папке
    // Если папки нет или ошибка, вернем пустой массив

    console.log("будем искать в каталоге -", directory);
    //const allFiles = readdirSync(directory);

     allFiles = readdirSync({
      path: directory
    }); 

    allFiles.forEach((fileName, index) => 
  {
    console.log(`${index + 1}. ${fileName}`);
  });

    if (!allFiles || allFiles.length === 0) {
       console.log("не нашли");
      return []
    }

   
    // 2. Приводим запрос к нижнему регистру для нечувствительности к регистру
    const lowerQuery = query.toLowerCase()

    console.log("фильтр",lowerQuery);

    // 3. Фильтруем массив
    const foundFiles = allFiles.filter((fileName) => {
      // Игнорируем системные файлы (если нужно)
      if (fileName === 'settings.data') return false

      // Проверяем, содержит ли имя файла строку запроса
      return fileName.toLowerCase().includes(lowerQuery)
    })

    return foundFiles

  } catch (e) {
    console.log('Ошибка поиска:', e)
    return []
  }
}

function filterFilesByMask(files, mask) {
  if (!files || !mask) return files;
  
  // Преобразуем маску в регулярное выражение
  // Например: "*.txt" -> "^.*\.txt$"
  const regexPattern = mask
    .replace(/\./g, '\\.')  // Экранируем точки
    .replace(/\*/g, '.*')   // * заменяем на .*
    .replace(/\?/g, '.');   // ? заменяем на .
  
  const regex = new RegExp('^' + regexPattern + '$', 'i');
  
  return files.filter(fileName => regex.test(fileName));
}


export function listDirectoryContents(path, fileMask = null) 
{
  let fileList;
  
  // Если указана маска файла, используем поиск по имени
  if (fileMask !== null && fileMask !== undefined && fileMask !== '') {
    console.log(`вызываем функцию поиска пр маске в каталоге`+path);
    const results = searchFilesByName(fileMask, path);
    fileList = results;
  } else {
    // Иначе читаем все файлы из директории
    console.log(`Директория "${path}" читаем от туда`);
    fileList = readdirSync({
      path: path
    });
  }
  
  // Проверяем, существует ли директория или есть ли результаты поиска
  if (fileList === undefined) {
    console.log(`Директория "${path}" не существует или файлы не найдены`);
    return;
  }
  
  // Проверяем, не пуста ли директория
  if (fileList.length === 0) {
    console.log(`Директория "${path}" пуста или файлы по маске "${fileMask}" не найдены`);
    return;
  }
  
  // Выводим список файлов
  console.log(`Содержимое директории "${path}":${fileMask ? ' (фильтр: ' + fileMask + ')' : ''}`);

  const myfiles = [];

  fileList.forEach((fileName, index) => 
  {
    console.log(`${index + 1}. ${fileName}`);
    myfiles.push({ title: `${fileName}` });
  });

  if (fileListWidget !== null) {
    try {
      deleteWidget(fileListWidget);
      console.log('Старый виджет удалён');
    } catch (e) {
      console.log('Ошибка удаления виджета: ' + e);
    }
    fileListWidget = null;
  }

  fileListWidget = createWidget(widget.SCROLL_LIST, {
    x: 90,
    y: 0,
    w: 292,
    h: 500,
    item_space: 12,
    item_config: [
      {
        item_height: 96,
        item_bg_color: 0x202020, // тёмно‑серый фон
        item_bg_radius: 18, 
        text_view: [
          {
            x: 12,
            y: 10,
            w: 268,
            h: 40,
            key: 'title',
            color: 0xFFFFFF,  // Максимально яркий белый
            text_size: 20,
            alpha: 255,       // Полная непрозрачность
            action: true,
          },
        ],
        text_view_count: 1,
      },
    ],
    item_config_count: 1,
    data_array: myfiles,
    data_count: myfiles.length,
    item_click_func: (list, index, key) => 
    {
      const item = myfiles[index];           
      const fileName = item.title;

      console.log('получили файл' + path + '/' + fileName);
    
      push({
        url: 'page/home/data.page',
        params: {
          from: path + '/' + fileName,
          value: 42,
        },
      });
    },
    enable_scroll_bar: true,
  });
}

// Функция для загрузки данных из файла
export function loadData(filename) 
{
  try {
    if (statSync(filename)) {
      const content = readFileSync({
        path: filename,
        options: {
          encoding: 'utf8'
        }
      });

      return content;
    }
  } catch (error) {
    console.log("Ошибка при загрузке:", error);
  }
  return null;
}



