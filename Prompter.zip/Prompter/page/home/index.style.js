import { px } from '@zos/utils'
import { getDeviceInfo } from '@zos/device'
import ui from '@zos/ui'

export const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = getDeviceInfo()

 export const ADD_BUTTON_STYLE = {
  x: px(390),
  y: px(110),
  w: px(60),
  h: px(70),
  text: "+",
  color: 0xffffff,
  text_size: px(32),
  normal_color: 0x00a86b,
  press_color: 0x007a4d,
  radius: px(8),
};

export const ADD_BUTTON_STYLE1 = {
    x: px(377),
    y: px(280),
    w: px(85),
    h: px(85),
    auto_scale: true,
    src: "phone1.png"

};

export const ADD_IMAGE_STYLE = {

    x: px(20),
    y: px(150),
    w: px(50),
    h: px(50),
    auto_scale: true,
    src: "images_add.png"

};

export const ADD_GAL_STYLE = {

    x: px(20),
    y: px(250),
    w: px(50),
    h: px(50),
    auto_scale: true,
    src: "images.png"

};

export const ADD_FIND_STYLE = {

    x: px(390),
    y: px(205),
    w: px(70),
    h: px(70),
    auto_scale: true,
    src: "find.png"

};


export const DELETE_BUTTON_STYLE = {
      x: 200,
      y: 430,
      w: 80,
      h: 50,
      text: '🗑️',
      color: 0xffffff,
      text_size: 18,
      normal_color: 0xff4444,
      press_color: 0xcc3333,
      radius: 8,
};

export const SAVE_BUTTON_STYLE = {
  x: px(20),
  y: px(400),
  w: DEVICE_WIDTH - px(40),
  h: px(60),
  text: "Edit",
  color: 0xffffff,
  text_size: px(32),
  normal_color: 0x1a6aff,
  press_color: 0x0051cc,
  radius: px(8),
};

