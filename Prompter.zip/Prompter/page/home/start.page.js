import * as hmUI from '@zos/ui'
import * as inbox from '@zos/inbox'

import { localStorage } from '@zos/storage'
import { createWidget, widget, align, text_style, prop } from '@zos/ui'
import { createKeyboard, inputType, deleteKeyboard } from '@zos/ui' // [web:1]
import { log as Logger } from '@zos/utils'
import { push } from '@zos/router'
import { listDirectoryContents, showKeyboardInput } from './utils.js'
import { BasePage } from '@zeppos/zml/base-page'
import { setPageBrightTime, resetPageBrightTime, setWakeUpRelaunch } from '@zos/display'
import { Time } from '@zos/sensor'
import { formatTimestampForFilename } from './fs'
import {
  ADD_BUTTON_STYLE,
  ADD_BUTTON_PHONE,
  ADD_IMAGE_STYLE,
  ADD_GAL_STYLE,
  ADD_FIND_STYLE,
  SETUP_STYLE,
} from './index.style.js'

const logger = Logger.getLogger('main-page')

Page(
  BasePage({
    onInit() {
      logger.debug('page onInit invoked')
      this.request({ method: 'init' })
      setPageBrightTime({ brightTime: 0 })
      setWakeUpRelaunch({ relaunch: true }) // Чтобы страница не закрывалась когда потухнет экран
    },

    build() {
      logger.debug('page build invoked')

      // Фон программы
      const img = createWidget(widget.IMG, {
        x: 0,
        y: 0,
        w: 480,
        h: 480,
        auto_scale: true,
        src: 'notes.png',
      })

      listDirectoryContents('TXT')

      // Кнопка добавления новой записи (+)
      const loadButton = createWidget(widget.BUTTON, ADD_BUTTON_STYLE)
      loadButton.addEventListener(hmUI.event.CLICK_UP, () => {
        showKeyboardInput('CHAR', 'NEW').then((value) => {
          if (value) {
            console.log('Введено:', value)

            push({
              url: 'page/home/add.page',
              params: {
                from: '',
                value,
              },
            })
          } else {
            console.log('Ввод отменён пользователем')

            push({
              url: 'page/home/add.page',
              params: {},
            })
          }
        })
      })

      // Кнопка добавления новой записи с телефона
      const loadforPhoneButton = createWidget(widget.BUTTON, ADD_BUTTON_PHONE)
      const phoneIp = localStorage.getItem('server_ip', '0.0.0.0') 
      
      loadforPhoneButton.addEventListener(hmUI.event.CLICK_UP, () => {
       this.request({
         method: 'GET_TEXT',
         params: {
          phoneIp: phoneIp,  // 📱 IP сервера телефона
        },
  })
      })

      // Кнопка получения картинки с телефона
      const loadImageButton = createWidget(widget.BUTTON, ADD_IMAGE_STYLE)
      loadImageButton.addEventListener(hmUI.event.CLICK_UP, () => {
        const time = new Time()
        const currentTimestamp = time.getTime()
        const filenameBase = formatTimestampForFilename(currentTimestamp) + '.png'
        
        const phoneIp = localStorage.getItem('server_ip', '0.0.0.0') 
        this.request({
          method: 'GET_IMAGE',
          params: {
            filename: filenameBase,
            phoneIp: phoneIp,  // 📱 IP сервера
    },
        })
      })

      // Кнопка открытия галереи
      const galleryButton = createWidget(widget.BUTTON, ADD_GAL_STYLE)
      galleryButton.addEventListener(hmUI.event.CLICK_UP, () => {
        push({
          url: 'page/home/gallery.page',
          params: {},
        })
      })

      // Кнопка открытия настроек
      const setupButton = createWidget(widget.BUTTON, SETUP_STYLE)
      setupButton.addEventListener(hmUI.event.CLICK_UP, () => {
        push({
          url: 'page/home/setup.page',
          params: {},
        })
      })

      // Кнопка поиска по имени заметки
      const imgButton = createWidget(widget.BUTTON, ADD_FIND_STYLE)
      imgButton.addEventListener(hmUI.event.CLICK_UP, () => {
        console.log('пришли в событие клика imgbutton')

        // initialText должен быть определён выше, если нужен стартовый текст
        createKeyboard({
          inputType: inputType.TEXT,
          text: initialText,
          onComplete: (_, result) => {
            const value = result.data || ''
            console.log('введено:', value)
            listDirectoryContents('TXT', value)
            deleteKeyboard()
          },
          onCancel: () => {
            deleteKeyboard()
          },
        })
      })
    },

    onDestroy() {
      logger.debug('page onDestroy invoked')
    },

    onRequest(req, res) {
      logger.debug('пришли в onRequest')
      hmUI.showToast({
        text: req.params,
      })
    },

    onCall(msg) {
      if (msg.method === 'onRequest') {
        hmUI.showToast({
          text: msg.params,
        })

        this.request({
          method: 'SAVE_IMAGE',
          params: msg.params,
        })
      } else if (msg.method === 'onFail') {
        hmUI.showToast({
          text: 'Ошибка загрузки.',
        })
      } else if (msg.method === 'onSaved') {
        const fileObject = inbox.getNextFile()
        hmUI.showToast({
          text: fileObject.filePath,
        })

        this.showImage(fileObject.filePath)
      } else if (msg.method === 'onTextReceived') {
        logger.debug('пришло вот это ' + msg.params)

        showKeyboardInput('CHAR', 'NEW').then((value) => {
          if (value) {
            console.log('Введено:', value)

            push({
              url: 'page/home/add.page',
              params: {
                from: msg.params,
                value,
              },
            })
          } else {
            console.log('Ввод отменён пользователем')

            push({
              url: 'page/home/add.page',
              params: {
                from: msg.params,
                value: '',
              },
            })
          }
        })
      }
    },
  }),
)
