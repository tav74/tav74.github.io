import * as hmUI from '@zos/ui'
import { createWidget, widget, prop } from '@zos/ui'
import { readdirSync, statSync, rmSync } from '@zos/fs'
import { onKey, KEY_UP, KEY_DOWN, KEY_BACK, KEY_SELECT, KEY_EVENT_CLICK } from '@zos/interaction'

Page({
  state: {
    images: [],
    currentIndex: 0,
    imageWidget: null,
    noImagesText: null,
    indexText: null,
    rotation: 0,
  },
  SCREEN_W: 480,
  SCREEN_H: 480,

  onInit() {
    console.log('=== onInit image gal ===')
    
    this.scanImages()
    this.buildUI()
    this.updateImage() // Теперь это сработает корректно, т.к. indexText уже создан в buildUI

    onKey({
      callback: (key, keyEvent) => {
        if (key === KEY_UP && keyEvent === KEY_EVENT_CLICK) {
          console.log('🔼 UP click')
          this.nextImage()
        } else if (key === KEY_DOWN && keyEvent === KEY_EVENT_CLICK) {
          console.log('🔽 DOWN click')
          this.prevImage()
        } else if (key === KEY_BACK && keyEvent === KEY_EVENT_CLICK) {
          hmApp.goBack()
        } else if (key === KEY_SELECT && keyEvent === KEY_EVENT_CLICK) {
          console.log('🔘 SELECT click')
          this.rotateImage()
        }
        return true
      },
    })
  },

  scanImages() {
    try {
      const files = readdirSync({ path: 'data://download/' })
      this.state.images = []
      
      if (!files || files.length === 0) {
        console.log('Директория data://download/ пуста')
        return
      }
      files.forEach((file) => {
        if (file.match(/\.(png|jpg|jpeg)$/i)) {
          const fullPath = `data://download/${file}`
          try {
            const stat = statSync({ path: fullPath })
            if (stat && stat.size > 0) {
              this.state.images.push(fullPath)
            }
          } catch (e) {
            console.log('stat skip:', file)
          }
        }
      })
      console.log('Найдено:', this.state.images.length)
    } catch (e) {
      console.log('scan error:', e)
      this.state.images = []
    }
  },

  buildUI() {
    // Текст "Нет изображений"
    this.state.noImagesText = createWidget(widget.TEXT, {
      x: 20,
      y: Math.floor(this.SCREEN_H / 2 - 40),
      w: this.SCREEN_W - 40,
      color: 0x888888,
      text_size: 22,
      align_h: 2,
      align_v: 2,
      text: 'Нет изображений\nUP-next ↓-prev SELECT-rotate',
    })

    // Виджет изображения
    this.state.imageWidget = createWidget(widget.IMG, {
      x: 0,
      y: 0,
      w: this.SCREEN_W,
      h: this.SCREEN_H,
      src: '',
      visible: false,
    })

    // --- ИЗМЕНЕНИЕ ---
    // Создаем виджет счетчика здесь, чтобы он был доступен сразу
    this.state.indexText = createWidget(widget.TEXT, {
      x: 230,
      y: 10,
      w: 200,
      color: 0xffffff,
      text_size: 18,
      text: '', // Текст будет установлен в updateImage
    })
  },

  updateImage() {
    console.log('updateImage, images:', this.state.images.length)
    this.state.rotation = 0
    this.applyRotation()
    
    if (this.state.images.length === 0) {
      this.state.imageWidget?.setProperty(prop.VISIBLE, false)
      this.state.noImagesText?.setProperty(prop.VISIBLE, true)
      this.state.indexText?.setProperty(prop.VISIBLE, false) // Скрываем счетчик, если нет картинок
      return
    }

    this.state.imageWidget.setProperty(prop.VISIBLE, true)
    const imgPath = this.state.images[this.state.currentIndex]
    this.state.imageWidget.setProperty(prop.SRC, imgPath)
    console.log('Show:', imgPath)
    
    this.state.noImagesText?.setProperty(prop.VISIBLE, false)
    
    // Теперь эта проверка сработает при первом запуске
    if (this.state.indexText) {
      this.state.indexText.setProperty(
        prop.TEXT,
        `${this.state.currentIndex + 1} / ${this.state.images.length}`
      )
      this.state.indexText.setProperty(prop.VISIBLE, true) // Показываем счетчик
    }
  },

  deleteCurrentImage() {
    if (this.state.images.length === 0) return
    
    const imgPath = this.state.images[this.state.currentIndex]
    console.log('🗑️ Удаляем:', imgPath)
    
    try {
      rmSync({ path: imgPath })
      console.log('✅ УДАЛЕН!')
      
      this.state.images.splice(this.state.currentIndex, 1)
      this.state.currentIndex = Math.min(this.state.currentIndex, this.state.images.length - 1)
      
      this.updateImage()
      console.log('📱 Осталось:', this.state.images.length)
    } catch (e) {
      console.log('❌ rmSync error:', e)
    }
  },

  prevImage() {
    if (this.state.images.length === 0) return
    this.state.currentIndex = (this.state.currentIndex - 1 + this.state.images.length) % this.state.images.length
    this.updateImage()
    console.log('PREV:', this.state.currentIndex)
  },

  nextImage() {
    if (this.state.images.length === 0) return
    this.state.currentIndex = (this.state.currentIndex + 1) % this.state.images.length
    this.updateImage()
    console.log('NEXT:', this.state.currentIndex)
  },

  rotateImage() {
    if (this.state.images.length === 0) return
    this.state.rotation = (this.state.rotation + 30) % 360 
    //this.state.rotation = (this.state.rotation + 90) % 360
    console.log('🔄 Rotate:', this.state.rotation + '°')
    this.applyRotation()
  },

  applyRotation() {
    if (this.state.imageWidget) {
      this.state.imageWidget.setProperty(prop.MORE, {
        angle: this.state.rotation,
      })
      console.log('🎯 Angle set:', this.state.rotation + '°')
    }
  },

  showDeleteDialog() {
    hmUI.createDialog({
      title: 'Delete?',
      show: true,
      auto_hide: true,
      cancel_text: 'No',
      confirm_text: 'Yes',
      click_listener: ({ type }) => { // Исправлено: click_listener
        console.log('dialog click type =', type)
        if (type === 1) {
          this.deleteCurrentImage()
        } else {
          console.log('Удаление отменено')
        }
      },
    })
  },

  build() {
    // --- ИЗМЕНЕНИЕ ---
    // Создание счетчика перенесено в buildUI, здесь осталась только кнопка.
    
    // Кнопка "УДАЛИТЬ"
    createWidget(widget.BUTTON, {
      x: 200,
      y: 430,
      w: 80,
      h: 50,
      text: '🗑️',
      color: 0xffffff,
      text_size: 24,
      normal_color: 0xff4444,
      press_color: 0xcc3333,
      radius: 8,
      click_func: () => {
        console.log('🗑️ УДАЛИТЬ')
        this.showDeleteDialog()
      },
    })
  },

  onDestroy() {
    console.log('onDestroy')
  },
})
