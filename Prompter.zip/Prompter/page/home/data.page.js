import { back } from '@zos/router'
import { createWidget, widget, align, prop, text_style } from '@zos/ui'
import * as hmUI from '@zos/ui'
import { rmSync } from '@zos/fs'
import { loadData } from './utils.js'
import { DELETE_BUTTON_STYLE } from './index.style.js'
import { SAVE_BUTTON_STYLE } from './index.style.js'

import { getDeviceInfo } from "@zos/device";


  const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = getDeviceInfo();

Page({

  state: {
    deleteButton: null,   // сюда сохраним виджет
  },


  onInit(params) {
    if (typeof params === 'string') {
      try {
        this.params = JSON.parse(params)
      } catch (e) {
        this.params = { raw: params }
      }
    } else {
      this.params = params || {}
    }

  
    
    
  },

  build() {

const img = createWidget(widget.IMG, 
  {
  x: 0,
  y: 0,
  w: 480,
  h: 480,
  auto_scale:true,
  src: "note3.png"
    })

    const { from = 'n/a', value = 'n/a' } = this.params  
      
     this.state.delButton = createWidget(widget.BUTTON, DELETE_BUTTON_STYLE);
    this.state.delButton.addEventListener(hmUI.event.CLICK_UP, () => 
      {
     
            this.showDeleteDialog(from);

      }); 

     
    const loadedData = loadData(from);

    console.log(from+' данные '+loadedData)
    
   
    
    
 const textWidget = createWidget(widget.TEXT, 
      {
        text: "Data",
        x: px(85),
        y: px(70),  // Под изображением и кнопкой
        w: DEVICE_WIDTH - px(40),
        h: DEVICE_HEIGHT - px(120),  // До низа экрана
        color: 0x000000,
        text_size: px(20),
        align_h: hmUI.align.LEFT,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.ELLIPSIS,  // Перенос строк
        line_space: px(4),  // Межстрочный интервал
    }) 
    


    textWidget.setProperty(prop.TEXT, loadedData); 

    
  },

  showDeleteDialog(filefordel) {
    const dialog = hmUI.createDialog({
      // Заголовок диалога (одна строка)
      title: 'Delete?',
      // Показать сразу после создания (можно и через dialog.show(true))
      show: true,
      // Автоматически скрывать диалог после нажатия кнопок
      auto_hide: true,
      // Тексты кнопок (левая = Cancel, правая = OK)
      cancel_text: 'No',
      confirm_text: 'Yes',
      // Единый обработчик нажатий
      click_linster: ({ type }) => {
        // type: 0 — Cancel, 1 — Confirm
        console.log('dialog click type =', type)

        if (type === 1) {
          // Пользователь нажал "Да"
          this.deleteFile(filefordel)
          back();

        } else {
          // Пользователь нажал "Нет"
          console.log('Удаление отменено')
        }
      },
    })

    // Если не указали show: true в опциях — покажем вручную:
    // dialog.show(true)
  },

  deleteFile(filefordel) 
  {
  
    try {        
      const res = rmSync(filefordel);
      this.state.delButton.setProperty(prop.TEXT, 'Deleted!')
    } catch (e) {
      console.log('Ошибка удаления', e)
      this.state.delButton.setProperty(prop.TEXT, 'Error deleting ', res)
    }
  },

});
