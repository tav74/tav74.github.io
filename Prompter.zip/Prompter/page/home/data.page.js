import { back } from '@zos/router'
import * as hmUI from '@zos/ui'
import { createWidget, widget, align, prop, text_style } from '@zos/ui'
import { rmSync } from '@zos/fs'
import { getDeviceInfo } from '@zos/device'
import { loadData } from './utils.js'
import { DELETE_BUTTON_STYLE, SAVE_BUTTON_STYLE } from './index.style.js'
import { getTextLayout } from '@zos/ui'
import { setPageBrightTime, resetPageBrightTime, setWakeUpRelaunch } from '@zos/display'

Page({
  state: {
    delButton: null, // сюда сохраним виджет
  },

  onInit(params) {

    setWakeUpRelaunch({relaunch: true});

    if (typeof params === 'string') {
      try {
        this.params = JSON.parse(params)
      } catch (e) {
        this.params = { raw: params }
      }
    } else {
      this.params = params || {}
    }
  },

  build() {

    let ypos = px(100)

    //createWidget(widget.PAGE_SCROLLBAR);

    // Фон
    const img = createWidget(widget.IMG, {
      x: 0,
      y: 0,
      w: 480,
      h: 480,
      auto_scale: true,
      src: 'note3.png',
    })


// Кнопка удаления
    this.state.delButton = createWidget(widget.BUTTON, DELETE_BUTTON_STYLE)
    this.state.delButton.addEventListener(hmUI.event.CLICK_UP, () => {
      this.showDeleteDialog(from)
    })


    const { from = 'n/a', value = 'n/a' } = this.params

    // Загрузка данных
    const loadedData = loadData(from)
    console.log(`${from} данные ${loadedData}`)
    
const { width, height } = getTextLayout(loadedData, {
  text_size: px(20),     // размер шрифта
  text_width: px(300),   // доступная ширина
  wrapped: 1             // 1 = перенос строк
})

console.log(`Высота: ${height} пикселей ширина  ${width}`)

//myw = width-40

    // Текстовый виджет с данными
    const textWidget = createWidget(widget.TEXT, {
      text: loadedData,
    
      x: px(40),
      y: ypos,
      w: px(480 - 40),
      h: height,

      color: 0x000000,
      text_size: px(20),
      align_h: hmUI.align.LEFT,
      align_v: hmUI.align.TOP,
      text_style: hmUI.text_style.WRAP,
      //line_space: px(4),
    })

  },

  showDeleteDialog(filefordel) {
    const dialog = hmUI.createDialog({
      title: 'Delete?',
      show: true,
      auto_hide: true,
      cancel_text: 'No',
      confirm_text: 'Yes',
      click_linster: ({ type }) => { // [web:6]
        console.log('dialog click type =', type)

        if (type === 1) {
          // Пользователь нажал "Да"
          this.deleteFile(filefordel)
          back()
        } else {
          // Пользователь нажал "Нет"
          console.log('Удаление отменено')
        }
      },
    })
  },

  deleteFile(filefordel) {
    try {
      const res = rmSync(filefordel)
      this.state.delButton.setProperty(prop.TEXT, 'Deleted!')
    } catch (e) {
      console.log('Ошибка удаления', e)
      this.state.delButton.setProperty(prop.TEXT, 'Error deleting')
    }
  },
})
