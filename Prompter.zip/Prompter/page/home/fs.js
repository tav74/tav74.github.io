
export function formatTimestampForFilename(currentTimestamp) {
  const d = new Date(currentTimestamp)

  const pad = (n) => (n < 10 ? `0${n}` : `${n}`)

  const day = pad(d.getDate())
  const month = pad(d.getMonth() + 1)    
  const year = d.getFullYear()

  const hours = pad(d.getHours())
  const minutes = pad(d.getMinutes())
  const seconds = pad(d.getSeconds())

  return `${day}.${month}.${year}_${hours}_${minutes}_${seconds}`
}

