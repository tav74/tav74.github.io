import { createWidget, widget, prop } from '@zos/ui';
import * as hmUI from '@zos/ui'
import { getText } from '@zos/i18n'
import { getDeviceInfo, SCREEN_SHAPE_SQUARE } from '@zos/device'
import { log as Logger } from '@zos/utils'
import { BasePage } from '@zeppos/zml/base-page'
import TransferFile from "@zos/ble/TransferFile"
import { setPageBrightTime, resetPageBrightTime } from '@zos/display'
import { setWakeUpRelaunch } from '@zos/display'
import { Time } from '@zos/sensor'
import { formatTimestampForFilename } from './fs'
import { push } from '@zos/router'


const transferFile = new TransferFile()
const inbox = transferFile.getInbox()

const logger = Logger.getLogger('todo-list-page')

Page(
  BasePage({

    state: {
      scrollList: null,
    },

    onInit() {
       setPageBrightTime({ brightTime: 0 }) 
       setWakeUpRelaunch({relaunch: true}); // Чтобы страница не закрывалась когда потухнет экран
      logger.debug('page onInit invoked')
      this.request({method: 'init'})  
    },

    build() {
      logger.debug('page build invoked')


      createWidget(widget.BUTTON, 
  {
      x: 125,
      y: 200,
      w: 230,
      h: 50,
      text: 'Загрузить текст',
      color: 0xffffff,
      text_size: px(16),
      normal_color: 0x00a86b,
      press_color: 0x007a4d,
      radius: px(8),

      click_func: () => 
        {        
                    
          this.request({
            method: 'GET_TEXT',
            params: filenameBase
      })


        }
  }) 

      createWidget(widget.BUTTON, 
  {
      x: 125,
      y: 400,
      w: 230,
      h: 50,
      text: 'Загрузить',
      color: 0xffffff,
      text_size: px(16),
      normal_color: 0x00a86b,
      press_color: 0x007a4d,
      radius: px(8),

      click_func: () => 
        {        
          
          const time = new Time(); // Создание экземпляра
          const currentTimestamp = time.getTime(); // Получение метки времени
          const filenameBase = formatTimestampForFilename(currentTimestamp)+'.png'
          console.log('Нажата кнопка загрузить_1, Имя файла ' +filenameBase)          
          
          this.request({
            method: 'GET_IMAGE',
            params: filenameBase
      })


        }
  }) 

     createWidget(widget.BUTTON, 
  {
      x: 125,
      y: 300,
      w: 230,
      h: 50,
      text: 'Галерея',
      color: 0xffffff,
      text_size: px(16),
      normal_color: 0x00a86b,
      press_color: 0x007a4d,
      radius: px(8),

      click_func: () => 
        {        
          
          console.log('Нажата кнопка галерея ' )          
          

  push({
            url: 'page/home/gallery.page',
            params: {
              from: fileName,
              value: 42,
            },
          });



        }
  }) 


  
    },

    onDestroy() {
      resetPageBrightTime()      
    },

    onRequest(req, res) {
      hmUI.showToast({
        text: req.params
      });
    },   

  showImage(path) {
  const screenWidth = 480
  const w = 300
  const x = (screenWidth - w) / 2  // 140
  const y = 50

  createWidget(widget.IMG, {
    x,
    y,
    w,
    h: 300,
    src: path,
    auto_scale: true
  })
},

     onCall(msg) {

      if (msg.method === "onRequest")
    {

       hmUI.showToast({
        text: msg.params
      });

     
      this.request({
            method: 'SAVE_IMAGE',
            params: msg.params
      })


    }
    else
      if (msg.method === "onFail")
      {
           hmUI.showToast({
          text: 'Ошибка загрузки.'
        });
      }
    else
      if (msg.method === "onSaved")
      {

        const fileObject = inbox.getNextFile()
        hmUI.showToast({
        text: fileObject.filePath
      
      }); 
        
        this.showImage(fileObject.filePath)

      }
      else
      if (msg.method === "onTextReceived")
      {
            hmUI.showToast({
            text: msg.params}); 

      }
      
      
    },
 
  
  })
)
