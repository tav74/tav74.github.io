package com.tav.android.nanohttpwebserver;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.widget.EditText;
import android.widget.Toast;

import fi.iki.elonen.NanoHTTPD;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public class AppHttpServer extends NanoHTTPD {

    private final Activity activity;
    private final File imagesDir;
    private volatile String storedText = ""; // Поле для хранения текста

    public AppHttpServer(Activity activity, File imagesDir) {
        super(8080); // Порт 8080
        this.activity = activity;
        this.imagesDir = imagesDir;
    }

    public void setEditTextValue(String text) {
        this.storedText = (text != null) ? text : "";
    }

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        Map<String, String> params = session.getParms();

        if (uri.equals("/")) {
            return serveStaticHtml("webview_ui.html");
        } else if (uri.equals("/api/greet")) {
            String name = params.get("name");
            if (name == null) name = "Guest";
            String json = "{\"message\": \"Hello, " + name + "!\"}";
            return newFixedLengthResponse(Response.Status.OK, "application/json", json);
        } else if (uri.startsWith("/special/")) {
            showRequestToast(uri);
            return serveImageFromDir(uri);
        }else if (uri.equals("/api/getText")) { // Новый маршрут
            showRequestToast(uri);
            return getTextFromEditText();
        }
        else {
            return serveStaticFile(uri);
        }
    }

    private void showRequestToast(String uri) {
        activity.runOnUiThread(() ->   // обновляем UI из фонового потока [web:185][web:199]
                Toast.makeText(activity,
                        "Запрос к " + uri,
                        Toast.LENGTH_SHORT
                ).show()
        );
    }



    private Response serveImageFromDir(String uri) {
        // /special/1.png -> 1.png
        String fileName = uri.substring("/special/".length());
        File file = new File(imagesDir, fileName);

        if (!file.exists()) {
            return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not Found");
        }

        String mime = "image/png";
        if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) mime = "image/jpeg";

        // Лучше стримить файл, а не читать полностью в память [web:124]
        try {
            FileInputStream fis = new FileInputStream(file);
            return newChunkedResponse(Response.Status.OK, mime, fis);
        } catch (IOException e) {
            return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "Error");
        }
    }


    // Метод для отдачи HTML-страницы из папки assets
    private Response serveStaticHtml(String filename) {
        try {
            AssetManager assets = activity.getAssets();
            InputStream stream = assets.open(filename);
            String mimeType = "text/html";
            return serveStream(stream, mimeType);
        } catch (IOException e) {
            String error = "<h1>File not found</h1>";
            return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/html", error);
        }
    }

    // Метод для отдачи других статических файлов (CSS, JS, изображения)
    private Response serveStaticFile(String uri) {
        try {
            // Убираем первый слэш в пути
            String assetPath = uri.substring(1);
            AssetManager assets = activity.getAssets();
            InputStream stream = assets.open(assetPath);

            // Определяем MIME-тип по расширению файла
            String mimeType = "text/plain";
            if (uri.endsWith(".css")) mimeType = "text/css";
            else if (uri.endsWith(".js")) mimeType = "application/javascript";
            else if (uri.endsWith(".png")) mimeType = "image/png";
            else if (uri.endsWith(".jpg") || uri.endsWith(".jpeg")) mimeType = "image/jpeg";

            return serveStream(stream, mimeType);
        } catch (IOException e) {
            return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not Found");
        }
    }

    private Response serveStream(InputStream stream, String mimeType) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int length;
        while ((length = stream.read(buffer)) != -1) {
            baos.write(buffer, 0, length);
        }
        byte[] bytes = baos.toByteArray();
        return newFixedLengthResponse(Response.Status.OK, mimeType, new ByteArrayInputStream(bytes), bytes.length);
    }

    private Response getTextFromEditText() {
        // Используем CountDownLatch для синхронизации потоков
        return newFixedLengthResponse(Response.Status.OK, "text/plain",
                storedText != null ? storedText : "Текст не задан");
    }
}