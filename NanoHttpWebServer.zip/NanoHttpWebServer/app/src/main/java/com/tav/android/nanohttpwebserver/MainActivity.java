package com.tav.android.nanohttpwebserver;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.format.Formatter;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private AppHttpServer server;
    private ImageView imageViewPreview;
    private static final int REQ_PICK_IMAGE = 1001;
    private File imagesDir;

    private static final int REQUEST_CODE_MAIN_ACTIVITY2 = 100;
    private String currentEditTextValue = ""; // Храним значение здесь

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        imagesDir = new File(getExternalFilesDir(null), "zepp_images");
        if (!imagesDir.exists()) {
            imagesDir.mkdirs();
        }

        webView = findViewById(R.id.webview);
        EditText ipTextEdit  = findViewById(R.id.ipTextEdit);

        WifiManager wifiMan = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        String ipAddress = Formatter.formatIpAddress(wifiMan.getConnectionInfo().getIpAddress());


        // Запускаем сервер
        try {
            server = new AppHttpServer(this,  imagesDir);
            server.start();
            ipTextEdit.setText("http://" + ipAddress + ":8080");
        } catch (IOException e) {
            ipTextEdit.setText("Failed to start server: " + e.getMessage());
            return;
        }

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true); // Включаем JavaScript
        webSettings.setDomStorageEnabled(true);
        //webView.loadUrl("http://alexeylab.ru/");
        webView.loadUrl("http://" + ipAddress + ":8080/");


        imageViewPreview = findViewById(R.id.imageViewPreview);
        Button buttonPickImage = findViewById(R.id.buttonPickImage);
        buttonPickImage.setOnClickListener(v -> {
            // Проверяем разрешение на чтение внешнего хранилища
                pickImage();

        });

        Button buttonNext = findViewById(R.id.buttonNext);
        buttonNext.setOnClickListener(v -> {

            Intent intent = new Intent(this, MainActivity2.class); // Создаем Intent
            intent.putExtra("EDIT_TEXT_VALUE", currentEditTextValue);
            startActivityForResult(intent, REQUEST_CODE_MAIN_ACTIVITY2);

        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), REQ_PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_PICK_IMAGE && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                copyImageToPrivateStorage(data.getData());
            }
        }
        else if (requestCode == REQUEST_CODE_MAIN_ACTIVITY2 && resultCode == RESULT_OK) {
            String receivedText = (data != null)
                    ? data.getStringExtra("EDIT_TEXT_VALUE")
                    : "";

            currentEditTextValue = receivedText;

            // Обновляем сервер через новый метод
            if (server != null) {
                server.setEditTextValue(currentEditTextValue);
            }

            // Для отладки
            Toast.makeText(this, "Текст сохранен на сервере: " + currentEditTextValue,
                    Toast.LENGTH_SHORT).show();
        }
    }
    private void copyImageToSpecialDir(Uri sourceUri) {
        try (InputStream in = getContentResolver().openInputStream(sourceUri)) {  // важно: через ContentResolver [web:111][web:123]
            File dst = new File(imagesDir, "1.png"); // либо генерируешь имя
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                try (OutputStream out = Files.newOutputStream(dst.toPath())) {
                    byte[] buf = new byte[8192];
                    int len;
                    while (true) {
                        assert in != null;
                        if ((len = in.read(buf)) == -1) break;
                        out.write(buf, 0, len);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void copyImageToPrivateStorage(Uri sourceUri) {
        final int TARGET_SIZE = 480;

        try {
            // --- ШАГ 1: Получаем размеры изображения, не загружая его в память ---
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true; // Эта опция позволяет "прочитать" метаданные без загрузки пикселей
            InputStream inputStreamForBounds = getContentResolver().openInputStream(sourceUri);
            BitmapFactory.decodeStream(inputStreamForBounds, null, options);
            if (inputStreamForBounds != null) {
                inputStreamForBounds.close();
            }

            int srcWidth = options.outWidth;
            int srcHeight = options.outHeight;

            // --- ШАG 2: Вычисляем inSampleSize для загрузки уменьшенной версии ---
            // inSampleSize - это коэффициент, который указывает, во сколько раз уменьшить изображение при загрузке.
            // Он должен быть степенью двойки.
            int inSampleSize = 1;
            if (srcHeight > TARGET_SIZE || srcWidth > TARGET_SIZE) {
                final int halfHeight = srcHeight / 2;
                final int halfWidth = srcWidth / 2;
                while ((halfHeight / inSampleSize) >= TARGET_SIZE && (halfWidth / inSampleSize) >= TARGET_SIZE) {
                    inSampleSize *= 2;
                }
            }
            options.inSampleSize = inSampleSize;
            options.inJustDecodeBounds = false; // Теперь разрешаем загрузку пикселей

            // --- ШАГ 3: Загружаем уже уменьшенное изображение в память ---
            InputStream inputStreamForBitmap = getContentResolver().openInputStream(sourceUri);
            Bitmap subsampledBitmap = BitmapFactory.decodeStream(inputStreamForBitmap, null, options);
            if (inputStreamForBitmap != null) {
                inputStreamForBitmap.close();
            }

            if (subsampledBitmap == null) {
                Toast.makeText(this, "Не удалось прочитать изображение", Toast.LENGTH_SHORT).show();
                return;
            }

            // --- ШАГ 4: Обрезаем до квадрата и масштабируем до TARGET_SIZE ---
            // Все операции делаем с уже уменьшенным subsampledBitmap, а не с оригиналом
            int newSize = Math.min(subsampledBitmap.getWidth(), subsampledBitmap.getHeight());
            int x = (subsampledBitmap.getWidth() - newSize) / 2;
            int y = (subsampledBitmap.getHeight() - newSize) / 2;

            Bitmap croppedBitmap = Bitmap.createBitmap(subsampledBitmap, x, y, newSize, newSize);

            // Переиспользуем subsampledBitmap, если обрезка не изменила объект
            if (croppedBitmap != subsampledBitmap) {
                subsampledBitmap.recycle();
            }

            Bitmap finalBitmap;
            if (croppedBitmap.getWidth() != TARGET_SIZE) {
                finalBitmap = Bitmap.createScaledBitmap(croppedBitmap, TARGET_SIZE, TARGET_SIZE, true);
                croppedBitmap.recycle(); // Освобождаем память сразу после создания отмасштабированной версии
            } else {
                finalBitmap = croppedBitmap; // Если размер уже 480x480, просто используем его
            }

            // --- ШАГ 5: Сохраняем и отображаем результат ---
            File destinationFile = new File(imagesDir, "1.png");
            try (FileOutputStream outputStream = new FileOutputStream(destinationFile)) {
                finalBitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            }

            runOnUiThread(() -> {
                imageViewPreview.setImageBitmap(finalBitmap);
                imageViewPreview.setVisibility(View.VISIBLE);
            });

            Toast.makeText(this,
                    "Изображение сохранено как 1.png\nРазмер: " + TARGET_SIZE + "x" + TARGET_SIZE + "px",
                    Toast.LENGTH_LONG).show();

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка при сохранении: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } catch (OutOfMemoryError e) {
            Toast.makeText(this, "Недостаточно памяти для обработки изображения", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        // Блок finally больше не нужен, так как мы используем try-with-resources для потоков
        // и своевременно вызываем recycle()
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (webView != null) {
            webView.destroy();
        }

        if (server != null) {
            server.stop(); // Останавливаем сервер при закрытии приложения
        }
    }

}