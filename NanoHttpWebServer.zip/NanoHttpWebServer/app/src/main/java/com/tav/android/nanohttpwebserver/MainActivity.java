package com.tav.android.nanohttpwebserver;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.format.Formatter;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private AppHttpServer server;
    private ImageView imageViewPreview;
    private static final int REQ_PICK_IMAGE = 1001;
    private File imagesDir;

    private static final int REQUEST_CODE_MAIN_ACTIVITY2 = 100;
    private String currentEditTextValue = ""; // Храним значение здесь

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        imagesDir = new File(getExternalFilesDir(null), "zepp_images");
        if (!imagesDir.exists()) {
            imagesDir.mkdirs();
        }

        webView = findViewById(R.id.webview);
        EditText ipTextEdit  = findViewById(R.id.ipTextEdit);

        WifiManager wifiMan = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        String ipAddress = Formatter.formatIpAddress(wifiMan.getConnectionInfo().getIpAddress());


        // Запускаем сервер
        try {
            server = new AppHttpServer(this,  imagesDir);
            server.start();
            ipTextEdit.setText("http://" + ipAddress + ":8080");
        } catch (IOException e) {
            ipTextEdit.setText("Failed to start server: " + e.getMessage());
            return;
        }

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true); // Включаем JavaScript
        webSettings.setDomStorageEnabled(true);
        //webView.loadUrl("http://alexeylab.ru/");
        webView.loadUrl("http://" + ipAddress + ":8080/");


        imageViewPreview = findViewById(R.id.imageViewPreview);
        Button buttonPickImage = findViewById(R.id.buttonPickImage);
        buttonPickImage.setOnClickListener(v -> {
            // Проверяем разрешение на чтение внешнего хранилища
                pickImage();

        });

        Button buttonNext = findViewById(R.id.buttonNext);
        buttonNext.setOnClickListener(v -> {

            Intent intent = new Intent(this, MainActivity2.class); // Создаем Intent
            intent.putExtra("EDIT_TEXT_VALUE", currentEditTextValue);
            startActivityForResult(intent, REQUEST_CODE_MAIN_ACTIVITY2);

        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), REQ_PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_PICK_IMAGE && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                copyImageToPrivateStorage(data.getData());
            }
        }
        else if (requestCode == REQUEST_CODE_MAIN_ACTIVITY2 && resultCode == RESULT_OK) {
            String receivedText = (data != null)
                    ? data.getStringExtra("EDIT_TEXT_VALUE")
                    : "";

            currentEditTextValue = receivedText;

            // Обновляем сервер через новый метод
            if (server != null) {
                server.setEditTextValue(currentEditTextValue);
            }

            // Для отладки
            Toast.makeText(this, "Текст сохранен на сервере: " + currentEditTextValue,
                    Toast.LENGTH_SHORT).show();
        }
    }
    private void copyImageToSpecialDir(Uri sourceUri) {
        try (InputStream in = getContentResolver().openInputStream(sourceUri)) {  // важно: через ContentResolver [web:111][web:123]
            File dst = new File(imagesDir, "1.png"); // либо генерируешь имя
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                try (OutputStream out = Files.newOutputStream(dst.toPath())) {
                    byte[] buf = new byte[8192];
                    int len;
                    while (true) {
                        assert in != null;
                        if ((len = in.read(buf)) == -1) break;
                        out.write(buf, 0, len);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void copyImageToPrivateStorage(Uri sourceUri) {
        final int TARGET_SIZE = 480;
        Bitmap original = null;
        Bitmap squared = null;
        Bitmap scaled = null;
        FileOutputStream outputStream = null;

        try {
            // 1. Декодируем Bitmap из Uri с проверкой потока
            InputStream inputStream = getContentResolver().openInputStream(sourceUri);
            if (inputStream == null) {
                Toast.makeText(this, "Не удалось открыть изображение", Toast.LENGTH_SHORT).show();
                return;
            }

            original = BitmapFactory.decodeStream(inputStream);
            inputStream.close();

            if (original == null) {
                Toast.makeText(this, "Не удалось прочитать изображение", Toast.LENGTH_SHORT).show();
                return;
            }

            // 2. Делаем квадратный кроп по центру
            int width = original.getWidth();
            int height = original.getHeight();
            int newSize = Math.min(width, height);

            // Проверка, нужно ли вообще обрезать
            if (newSize <= 0) {
                Toast.makeText(this, "Некорректный размер изображения", Toast.LENGTH_SHORT).show();
                return;
            }

            int x = (width - newSize) / 2;
            int y = (height - newSize) / 2;

            squared = Bitmap.createBitmap(original, x, y, newSize, newSize);

            // 3. Масштабируем до 480x480 (если размер уже меньше, всё равно масштабируем для единообразия)
            scaled = Bitmap.createScaledBitmap(squared, TARGET_SIZE, TARGET_SIZE, true);

            // 4. Сохраняем в PNG с перезаписью
            String fileName = "1.png";
            File destinationFile = new File(imagesDir, fileName);

            // Создаем директорию, если не существует
            if (!imagesDir.exists()) {
                imagesDir.mkdirs();
            }

            outputStream = new FileOutputStream(destinationFile);
            // PNG игнорирует параметр качества, но 100 указывает на максимальное сжатие без потерь
            scaled.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.flush();

            // 5. Обновляем превью
            final Bitmap finalBitmapForPreview = Bitmap.createBitmap(scaled); // Создаем копию для превью
            runOnUiThread(() -> {
                imageViewPreview.setImageBitmap(finalBitmapForPreview);
                imageViewPreview.setVisibility(View.VISIBLE);

                // Освобождаем копию, когда она больше не нужна (после установки в ImageView)
                // На практике ImageView управляет своей Bitmap, но явное освобождение не помешает
                // finalBitmapForPreview.recycle(); // Не обязательно, но можно раскомментировать
            });

            Toast.makeText(this,
                    "Изображение сохранено как 1.png\nРазмер: " + TARGET_SIZE + "x" + TARGET_SIZE + "px",
                    Toast.LENGTH_LONG).show();

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка при сохранении: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } catch (OutOfMemoryError e) {
            Toast.makeText(this, "Недостаточно памяти для обработки изображения", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        } finally {
            // 6. Очистка ресурсов в правильном порядке
            try {
                if (outputStream != null) {
                    outputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Освобождаем Bitmap'ы
            if (scaled != null && scaled != squared && scaled != original) {
                scaled.recycle();
            }
            if (squared != null && squared != original) {
                squared.recycle();
            }
            if (original != null) {
                original.recycle();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (webView != null) {
            webView.destroy();
        }

        if (server != null) {
            server.stop(); // Останавливаем сервер при закрытии приложения
        }
    }

}