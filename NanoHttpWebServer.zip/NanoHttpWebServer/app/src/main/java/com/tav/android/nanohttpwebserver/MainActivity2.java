package com.tav.android.nanohttpwebserver;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        Button saveButton = findViewById(R.id.saveButton);
        EditText editText = findViewById(R.id.editTextText);

        Intent receivedIntent = getIntent();
        if (receivedIntent != null && receivedIntent.hasExtra("EDIT_TEXT_VALUE")) {
            String previousText = receivedIntent.getStringExtra("EDIT_TEXT_VALUE");
            editText.setText(previousText);
            // Устанавливаем курсор в конец текста
            editText.setSelection(editText.getText().length());
        }

        saveButton.setOnClickListener(v -> {

            String text = editText.getText().toString();

            Intent resultIntent = new Intent();
            resultIntent.putExtra("EDIT_TEXT_VALUE", text);
            setResult(RESULT_OK, resultIntent);
            finish(); // Закрываем MainActivity2
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}